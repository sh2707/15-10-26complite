﻿using System;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace PDCA_Sender.Services
{
        public class TcpService
        {
            // Timing of the last send (ms) - shown in the status bar to see where the delay is.
            public long LastConnectMs { get; private set; }
            public long LastReplyMs { get; private set; }

            public async Task<bool> TestConnectionAsync(
                string ip,
                int port)
            {
                try
                {
                    using (TcpClient client = new TcpClient())
                    {
                        var connectTask =
                            client.ConnectAsync(ip, port);

                        var timeoutTask =
                            Task.Delay(3000);

                        var completedTask =
                            await Task.WhenAny(
                                connectTask,
                                timeoutTask);

                        if (completedTask == timeoutTask)
                            return false;

                        return client.Connected;
                    }
                }
                catch
                {
                    return false;
                }
            }


            public async Task<string> SendAsync(
                string ip,
                int port,
                string data)
            {
                using (TcpClient client = new TcpClient())
                {
                    client.NoDelay = true;
                    Stopwatch sw = Stopwatch.StartNew();

                    // Literal IP: connect directly (no DNS lookup). ConfigureAwait(false): no UI-thread hops while sending.
                    IPAddress address;
                    if (IPAddress.TryParse(ip, out address))
                        await client.ConnectAsync(address, port).ConfigureAwait(false);
                    else
                        await client.ConnectAsync(ip, port).ConfigureAwait(false);

                    LastConnectMs = sw.ElapsedMilliseconds;

                    NetworkStream stream =
                        client.GetStream();

                    byte[] sendData =
                        Encoding.UTF8.GetBytes(data);

                    await stream.WriteAsync(
                        sendData,
                        0,
                        sendData.Length).ConfigureAwait(false);

                    sw.Restart();

                    byte[] buffer =
                        new byte[8192];

                    int received =
                        await stream.ReadAsync(
                            buffer,
                            0,
                            buffer.Length).ConfigureAwait(false);

                    LastReplyMs = sw.ElapsedMilliseconds;

                    if (received == 0)
                        return "No response received.";

                    string response =
                        Encoding.UTF8.GetString(
                            buffer,
                            0,
                            received);

                    return response;
                }
            }
        }
    
}
