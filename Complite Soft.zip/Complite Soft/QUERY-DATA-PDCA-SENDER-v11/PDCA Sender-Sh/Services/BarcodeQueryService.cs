using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace PDCA_Sender.Services
{
    public class BarcodeQueryService
    {
        private readonly HttpClient _client;

        public BarcodeQueryService()
        {
            _client = new HttpClient();
            _client.Timeout = TimeSpan.FromSeconds(10);
        }

        public async Task<string> GetAsync(string url, string panelSn, string method = "GET")
        {
            if (string.IsNullOrWhiteSpace(url))
                throw new ArgumentException("Barcode Query URL is empty.");

            if (string.IsNullOrWhiteSpace(panelSn))
                throw new ArgumentException("Panel SN is empty.");

            string requestUrl = url.Replace("{PANEL_SN}", Uri.EscapeDataString(panelSn));
            requestUrl = requestUrl.Replace("{PANEL}", Uri.EscapeDataString(panelSn));
            requestUrl = requestUrl.Replace("{JIGSN}", Uri.EscapeDataString(panelSn));

            HttpResponseMessage response;
            if (string.Equals(method, "POST", StringComparison.OrdinalIgnoreCase))
            {
                // Keep query-string parameters intact; some PDCA endpoints require POST
                // even when their parameters are supplied in the URL.
                using (var content = new StringContent(string.Empty))
                    response = await _client.PostAsync(requestUrl, content);
            }
            else
            {
                response = await _client.GetAsync(requestUrl);
            }

            using (response)
            {
                string body = await response.Content.ReadAsStringAsync();
                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception("Barcode query HTTP " + (int)response.StatusCode + ": " + body);
                }
                return body;
            }
        }
    }
}
