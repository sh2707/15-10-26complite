using System.Net;
using System.Net.Sockets;
using System.Text;

namespace TcpTerminal;

public class MainForm : Form
{
    // ---- UI controls ----
    private readonly ComboBox cmbMode = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 80 };
    private readonly TextBox txtIp = new() { Text = "127.0.0.1", Width = 130 };
    private readonly TextBox txtPort = new() { Text = "5000", Width = 60 };
    private readonly Button btnConnect = new() { Text = "Connect", Width = 85 };
    private readonly Button btnStop = new() { Text = "Disconnect", Width = 85, Enabled = false };
    private readonly Button btnClear = new() { Text = "Clear", Width = 60 };
    private readonly RichTextBox console = new();
    private readonly TextBox txtSend = new();
    private readonly CheckBox chkCrlf = new() { Text = "Add \\r\\n", Checked = true, AutoSize = true };
    private readonly Button btnSend = new() { Text = "Send", Width = 70 };
    private readonly Label lblStatus = new() { Text = "Disconnected", Dock = DockStyle.Bottom, Padding = new Padding(6, 3, 0, 3), Height = 24 };

    // ---- networking state ----
    private TcpClient? client;
    private TcpListener? listener;
    private NetworkStream? stream;
    private CancellationTokenSource? cts;

    public MainForm()
    {
        Text = "TCP Terminal";
        Width = 860;
        Height = 580;
        MinimumSize = new Size(680, 420);

        cmbMode.Items.AddRange(new object[] { "Client", "Server" });
        cmbMode.SelectedIndex = 0;
        cmbMode.SelectedIndexChanged += (_, _) => ModeChanged();

        // top bar
        var top = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 42, Padding = new Padding(6, 8, 6, 0), WrapContents = false };
        top.Controls.AddRange(new Control[]
        {
            Lbl("Mode"), cmbMode, Lbl("IP Address"), txtIp, Lbl("Port"), txtPort, btnConnect, btnStop, btnClear
        });

        // console (cmd-prompt look)
        console.Dock = DockStyle.Fill;
        console.BackColor = Color.FromArgb(12, 12, 12);
        console.ForeColor = Color.LightGray;
        console.Font = new Font("Consolas", 11);
        console.ReadOnly = true;
        console.BorderStyle = BorderStyle.None;

        // bottom send bar
        var bottom = new Panel { Dock = DockStyle.Bottom, Height = 40, Padding = new Padding(6) };
        btnSend.Dock = DockStyle.Right;
        chkCrlf.Dock = DockStyle.Right;
        txtSend.Dock = DockStyle.Fill;
        bottom.Controls.Add(txtSend);
        bottom.Controls.Add(chkCrlf);
        bottom.Controls.Add(btnSend);

        Controls.Add(console);
        Controls.Add(bottom);
        Controls.Add(top);
        Controls.Add(lblStatus);

        btnConnect.Click += async (_, _) => await StartAsync();
        btnStop.Click += (_, _) => Stop();
        btnClear.Click += (_, _) => console.Clear();
        btnSend.Click += async (_, _) => await SendAsync();
        txtSend.KeyDown += async (_, e) =>
        {
            if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; await SendAsync(); }
        };
        FormClosing += (_, _) => Stop(log: false);
    }

    private static Label Lbl(string t) => new() { Text = t, AutoSize = true, Margin = new Padding(6, 5, 2, 0) };

    private void ModeChanged()
    {
        if (cmbMode.Text == "Server") { txtIp.Text = "0.0.0.0"; btnConnect.Text = "Listen"; }
        else { txtIp.Text = "127.0.0.1"; btnConnect.Text = "Connect"; }
    }

    // ---- console helper (thread-safe) ----
    private void Log(string text, Color color)
    {
        if (InvokeRequired) { BeginInvoke(() => Log(text, color)); return; }
        console.SelectionStart = console.TextLength;
        console.SelectionColor = color;
        console.AppendText($"[{DateTime.Now:HH:mm:ss}] {text}\n");
        console.ScrollToCaret();
    }

    private void SetStatus(string s)
    {
        if (InvokeRequired) { BeginInvoke(() => SetStatus(s)); return; }
        lblStatus.Text = s;
    }

    private void SetButtons(bool running)
    {
        if (InvokeRequired) { BeginInvoke(() => SetButtons(running)); return; }
        btnConnect.Enabled = !running;
        btnStop.Enabled = running;
    }

    // ---- connection control ----
    private async Task StartAsync()
    {
        if (!int.TryParse(txtPort.Text, out int port) || port < 1 || port > 65535)
        {
            Log("Invalid port (use 1-65535)", Color.Tomato);
            return;
        }
        string ip = txtIp.Text.Trim();
        cts = new CancellationTokenSource();
        var token = cts.Token;
        SetButtons(true);

        try
        {
            if (cmbMode.Text == "Client")
            {
                SetStatus($"Connecting to {ip}:{port} ...");
                client = new TcpClient();
                await client.ConnectAsync(ip, port, token);
                stream = client.GetStream();
                Log($"Connected to {ip}:{port}", Color.Gold);
                SetStatus($"Connected to {ip}:{port}");
                await ReceiveLoopAsync(stream, token);
                if (!token.IsCancellationRequested) Log("Connection closed by remote", Color.Gold);
            }
            else
            {
                listener = new TcpListener(IPAddress.Parse(ip), port);
                listener.Start();
                Log($"Listening on {ip}:{port} ...", Color.Gold);
                SetStatus($"Listening on {ip}:{port}");
                while (!token.IsCancellationRequested)
                {
                    client = await listener.AcceptTcpClientAsync(token);
                    stream = client.GetStream();
                    var ep = client.Client.RemoteEndPoint;
                    Log($"Client connected: {ep}", Color.Gold);
                    SetStatus($"Client {ep} connected");
                    await ReceiveLoopAsync(stream, token);
                    if (!token.IsCancellationRequested)
                    {
                        Log("Client disconnected, waiting for next ...", Color.Gold);
                        SetStatus($"Listening on {ip}:{port}");
                    }
                }
            }
        }
        catch (OperationCanceledException) { }
        catch (Exception ex)
        {
            Log($"Error: {ex.Message}", Color.Tomato);
        }
        finally
        {
            if (!token.IsCancellationRequested) Stop();
        }
    }

    private async Task ReceiveLoopAsync(NetworkStream s, CancellationToken token)
    {
        var buf = new byte[4096];
        try
        {
            while (!token.IsCancellationRequested)
            {
                int n = await s.ReadAsync(buf, token);
                if (n == 0) break;
                string text = Encoding.UTF8.GetString(buf, 0, n).TrimEnd('\r', '\n');
                Log("RX: " + text, Color.SpringGreen);
            }
        }
        catch (OperationCanceledException) { }
        catch (IOException) { }
        catch (ObjectDisposedException) { }
    }

    private void Stop(bool log = true)
    {
        try { cts?.Cancel(); } catch { }
        try { stream?.Close(); } catch { }
        try { client?.Close(); } catch { }
        try { listener?.Stop(); } catch { }
        stream = null; client = null; listener = null;
        SetButtons(false);
        SetStatus("Disconnected");
        if (log) Log("Disconnected", Color.Gold);
    }

    private async Task SendAsync()
    {
        if (stream == null) { Log("Not connected", Color.Tomato); return; }
        string text = txtSend.Text;
        if (text.Length == 0) return;
        try
        {
            byte[] data = Encoding.UTF8.GetBytes(text + (chkCrlf.Checked ? "\r\n" : ""));
            await stream.WriteAsync(data);
            Log("TX: " + text, Color.DeepSkyBlue);
            txtSend.Clear();
        }
        catch (Exception ex)
        {
            Log($"Send failed: {ex.Message}", Color.Tomato);
        }
    }
}
