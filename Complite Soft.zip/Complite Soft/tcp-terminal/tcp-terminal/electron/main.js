const { app, BrowserWindow, ipcMain } = require('electron');
const net = require('net');
const path = require('path');

let win;
let client = null;   // active data socket
let server = null;   // listening server (server mode)

function createWindow() {
  win = new BrowserWindow({
    width: 860,
    height: 580,
    minWidth: 680,
    minHeight: 420,
    title: 'TCP Terminal',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  win.setMenuBarVisibility(false);
  win.loadFile('index.html');
}

function emit(type, text) {
  if (win && !win.isDestroyed()) win.webContents.send('tcp-event', { type, text });
}

function wireSocket(sock) {
  client = sock;
  sock.on('data', (buf) => emit('rx', buf.toString('utf8').replace(/[\r\n]+$/, '')));
  sock.on('error', (err) => emit('err', `Socket error: ${err.message}`));
  sock.on('close', () => {
    if (client === sock) client = null;
    if (server) {
      emit('info', 'Client disconnected, waiting for next ...');
      emit('status', `Listening on ${server.address()?.address}:${server.address()?.port}`);
    } else {
      emit('info', 'Connection closed');
      emit('stopped', '');
    }
  });
}

function stopAll() {
  if (client) { client.destroy(); client = null; }
  if (server) { server.close(); server = null; }
}

ipcMain.handle('start', (_e, { mode, ip, port }) => {
  stopAll();
  if (mode === 'Client') {
    emit('status', `Connecting to ${ip}:${port} ...`);
    const sock = net.createConnection({ host: ip, port }, () => {
      emit('info', `Connected to ${ip}:${port}`);
      emit('status', `Connected to ${ip}:${port}`);
    });
    sock.setTimeout(5000, () => {
      if (sock.connecting) { emit('err', 'Connection timed out'); sock.destroy(); emit('stopped', ''); }
      else sock.setTimeout(0);
    });
    sock.once('connect', () => sock.setTimeout(0));
    sock.once('error', () => { if (sock.connecting || !client) emit('stopped', ''); });
    wireSocket(sock);
  } else {
    server = net.createServer((sock) => {
      emit('info', `Client connected: ${sock.remoteAddress}:${sock.remotePort}`);
      emit('status', `Client ${sock.remoteAddress}:${sock.remotePort} connected`);
      if (client) client.destroy();
      wireSocket(sock);
    });
    server.on('error', (err) => { emit('err', `Cannot listen: ${err.message}`); server = null; emit('stopped', ''); });
    server.listen(port, ip, () => {
      emit('info', `Listening on ${ip}:${port} ...`);
      emit('status', `Listening on ${ip}:${port}`);
    });
  }
});

ipcMain.handle('stop', () => {
  stopAll();
  emit('info', 'Disconnected');
  emit('status', 'Disconnected');
  emit('stopped', '');
});

ipcMain.handle('send', (_e, text) => {
  if (!client) { emit('err', 'Not connected'); return false; }
  client.write(text);
  return true;
});

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { stopAll(); app.quit(); });
