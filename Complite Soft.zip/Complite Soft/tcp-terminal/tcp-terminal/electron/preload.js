const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('tcp', {
  start: (opts) => ipcRenderer.invoke('start', opts),
  stop: () => ipcRenderer.invoke('stop'),
  send: (text) => ipcRenderer.invoke('send', text),
  onEvent: (cb) => ipcRenderer.on('tcp-event', (_e, data) => cb(data)),
});
