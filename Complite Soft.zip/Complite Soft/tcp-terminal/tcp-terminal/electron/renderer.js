const $ = (id) => document.getElementById(id);
const consoleEl = $('console');

function log(text, cls) {
  const t = new Date().toTimeString().slice(0, 8);
  const line = document.createElement('div');
  line.className = cls || '';
  line.textContent = `[${t}] ${text}`;
  consoleEl.appendChild(line);
  consoleEl.scrollTop = consoleEl.scrollHeight;
}

function setRunning(running) {
  $('connect').disabled = running;
  $('stop').disabled = !running;
}

$('mode').addEventListener('change', () => {
  if ($('mode').value === 'Server') {
    $('ip').value = '0.0.0.0';
    $('connect').textContent = 'Listen';
  } else {
    $('ip').value = '127.0.0.1';
    $('connect').textContent = 'Connect';
  }
});

$('connect').addEventListener('click', () => {
  const port = parseInt($('port').value, 10);
  if (!(port > 0 && port < 65536)) { log('Invalid port (use 1-65535)', 'err'); return; }
  setRunning(true);
  window.tcp.start({ mode: $('mode').value, ip: $('ip').value.trim(), port });
});

$('stop').addEventListener('click', () => window.tcp.stop());
$('clear').addEventListener('click', () => { consoleEl.innerHTML = ''; });

async function send() {
  const text = $('msg').value;
  if (!text) return;
  const ok = await window.tcp.send(text + ($('crlf').checked ? '\r\n' : ''));
  if (ok) { log('TX: ' + text, 'tx'); $('msg').value = ''; }
}
$('send').addEventListener('click', send);
$('msg').addEventListener('keydown', (e) => { if (e.key === 'Enter') send(); });

window.tcp.onEvent(({ type, text }) => {
  if (type === 'rx') log('RX: ' + text, 'rx');
  else if (type === 'info') log(text, 'info');
  else if (type === 'err') log(text, 'err');
  else if (type === 'status') $('status').textContent = text;
  else if (type === 'stopped') { setRunning(false); $('status').textContent = 'Disconnected'; }
});
